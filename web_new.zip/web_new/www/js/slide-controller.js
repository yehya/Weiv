/* global jQuery, $ */

var slideController = {
    _contentDiv: $("slide-content"),
    _instructor: null, // Name of Instructor
    _lectureName: null, // holds current lecture name
    _lectureCourse: null, // course
    _lectureID: null, // holds current lecture id
    _lectureTheme: null, // holds CSS that changes the theme
    _slides: [], // holds all slides
    _currSlide: null, // current slide on display
    _slideSequence: null, // slide number
    _entitySequence: null, // entity number
    _soundOn: false, // whether sound is on or not.
    loadLecture: function(lectureData) {
        this._lectureID = lectureData.id;
        this._lectureName = lectureData.title;
        this._lectureCourse = lectureData.course;
        this._instructor = lectureData.instructor;
        this._lectureTheme = lectureData.theme;
        this._slides = lectureData.slides;
    },
    toggleSound: function() {
        if (this._soundOn) {
            this._soundOn = false;
        }
        else {
            this._soundOn = true;
        }
    },
    isSoundOn: function() {
        return this._soundOn;
    },
    next: function() { // could be slide or animation

    },
    previous: function() { // could be slide or animation

    },
    nextSlide: function() {

    },
    prevSlide: function() {

    }
};
